#ifndef T_H
#define T_H


class t
{
    public:
        t();
        virtual ~t();

    protected:

    private:
};

#endif // T_H
